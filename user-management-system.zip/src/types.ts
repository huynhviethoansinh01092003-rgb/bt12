export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'User' | 'Editor';
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export type UserInput = Omit<User, 'id' | 'createdAt'>;
